package zygosity_evaluator;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import utility.AllelicInfo;
import utility.DetailedVariantRecord;
import utility.MultisampleVariantRecord;
import zygosity_evaluator.PopulationDataStructure.population;
/**
 * This class is only intended to evaluate autosomal DNA.
 */
public class ZygosityEvaluator 
{
	private enum population {AFR,AMR,ASN,ASW,CEU,CHB,CHS,
		CLM,EUR,FIN,GBR,IBS,JPT,LWK,MXL,PUR,TSI,YRI,all};
	MultisampleVariantRecord msvr;
	DetailedVariantRecord dvr;
	PopulationDataStructure pds;
    private String[] sampleNames;
	private HashMap <population, Integer> HeterozygousCount;
	private HashMap <population, Integer> HomozygousRefMatchCount;
	private int anncestralAlleleFlag; // put this in DVR?
	private int[] zygosity_of_people;
	BufferedReader reader;
	BufferedWriter writer;
	public ZygosityEvaluator(String chromosomeFile, String populationFile, String outFile)
	{		
		zygosity_of_people = new int[1092];
		pds = new PopulationDataStructure(populationFile);
		HomozygousRefMatchCount = new HashMap <population, Integer>(19);
		HeterozygousCount = new HashMap <population, Integer>(19);		
		for(population p: population.values())
		{
			HomozygousRefMatchCount.put(p, 0);
			HeterozygousCount.put(p, 0);
		}
		driver(chromosomeFile, outFile);
		
	}
	private void driver(String chromosomeFile, String outFile)
	{
		try
		{
			reader = new BufferedReader(new FileReader(chromosomeFile), 67108864);
			writer = new BufferedWriter(new FileWriter(outFile), 67108864);
			String line = reader.readLine();
			while(line != null) 
		    {
			if(line.matches("#CHROM.*")) //We found the header line!
			    {				
				setSamples(line);
				break;
			    }
			else
			    line = reader.readLine();		     
		    }
		line = reader.readLine();
		while(line != null)
		    {			
			dvr  = new DetailedVariantRecord(line);
			if(!dvr.getIsIndel())
			    {
					msvr = new MultisampleVariantRecord(line, sampleNames);
					evaluateFractions();
					writeRecord();
			    }
			line = reader.readLine();
		    }
		writer.close();
		reader.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(0);
		}
	}
	private void writeRecord()
	{
		try
		{
			double temp_heterozygous_fraction = 0.0;
			double temp_homozygous_fraction = 0.0;
			ArrayList<Integer> tempPopulationMap;
			// Note that java guaratees that foreach loops and enum arrays are ordered.
			for(population p: population.values())
			{
				tempPopulationMap = pds.getPopulationMap().get(p);
				temp_heterozygous_fraction = HeterozygousCount.get(p)/((double) tempPopulationMap.size());
				temp_homozygous_fraction = HomozygousRefMatchCount.get(p)/((double) tempPopulationMap.size());
				
				writer.write(HeterozygousCount.get(p)+ "`");
				writer.write(temp_heterozygous_fraction + "`");
				writer.write(HomozygousRefMatchCount.get(p) + "`");
				writer.write(temp_homozygous_fraction + "`");
			}
			writer.write(dvr.get_AncestralAlleleFlag() + "\n");
		}		
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(0);			
		}
	}
	private void evaluateFractions()
	{
		AllelicInfo[] myAllelicInfoArray = msvr.getAllelicInfoArray();
		//ArrayList<Integer> tempPopulationMap;
		for(int i=0; i < 1092; i++)
		{
			try
			{
				zygosity_of_people[i] = evaluateZygosity(myAllelicInfoArray[i]);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.exit(0);
			}
		}
		for(population p: population.values())
		{
			// spin through pds and update HeterozygousCount and 
			// HomozygousRefMatchCount for each population in pds
			
			int temp_heterozygousCount = 0;
			/**********************************************************************************/
			/***********************Debugging block********************************************/
			HashMap<zygosity_evaluator.PopulationDataStructure.population, ArrayList<Integer>> myMap = pds.getPopulationMap();
			String[] populationArray = {"AFR","AMR","ASN","ASW","CEU","CHB","CHS",
				"CLM","EUR","FIN","GBR","IBS","JPT","LWK","MXL","PUR","TSI","YRI","all"};
			
			ArrayList<Integer> temp = myMap.get(population.valueOf("all"));
			

			for(String s: populationArray)
			{
				System.out.println("There exits a(n) " + s + " key: " + myMap.containsKey(population.valueOf(s)));
				System.out.println("The size of the array is: " + myMap.get(population.valueOf(s)).size());			
			}
			System.exit(1);
			/**********************************************************************************/
			
			/*
			for(int j: pds.getPopulationMap().get(p))
			{
				switch(zygosity_of_people[j])
				{
				case  0:
					HeterozygousCount.put(p, HeterozygousCount.get(p) + 1);
					break;
				case  1:
					HomozygousRefMatchCount.put(p, HomozygousRefMatchCount.get(p) + 1);
					break;
				}
			}//*/
		}	
	}	
	private int evaluateZygosity(AllelicInfo a) throws Exception
	{
		/*  0 iff homozygous reference match
		 *  1 iff heterozygous
		 * -1 homozygous variant match.
		 */
		if(isHomozygousRefMatch(a))
			return  0;
		else if(isHeterozygous(a))
			return  1;
		else 
		{
			throw new Exception("Error. Invalid zygosity!");			
		}
	}
	private boolean isHomozygousRefMatch(AllelicInfo a)
	{
		if(a.getImputedGenotype().equals("ref,ref"))
			return true;
		else
			return false;
	}
	private boolean isHeterozygous(AllelicInfo a)

	{
		String[] valArray = a.getImputedGenotype().split(",");
		try
		{
			if(valArray.length != 2)
				throw new Exception("Non-diploid allele detected!");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(0);
		}
		if(valArray[0].equals(valArray[1]))
			return false;
		else
			return true;			
	}
    private void setSamples(String line)
    {
	//System.out.println(line);
	String[] myArray = line.split("\t");
	sampleNames = new String[myArray.length - 9];
	for(int i = 9; i < myArray.length; i++)
	    {
		sampleNames[i-9] = myArray[i].trim();
	    }
	}
}
